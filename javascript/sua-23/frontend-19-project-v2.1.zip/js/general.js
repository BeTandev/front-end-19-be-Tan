// create axios instance
const API = axios.create({
  baseURL: 'https://apiforlearning.zendvn.com/api/v2/',
});

const elSearchForm = document.getElementById('search-form');
const elInputKeyword = document.querySelector('input[name="keyword"]');

elSearchForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const keyword = elInputKeyword.value.trim();
  if (keyword) {
    elSearchForm.submit();
  } else {
    alert('Vui long nhap tu khoa can tim!');
  }
});
